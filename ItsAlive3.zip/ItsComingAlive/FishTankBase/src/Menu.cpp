#include "Menu.hpp"

extern GLint coordinate;
extern GLint type, xBegin;
extern World myWorld;
extern Camera myCamera;
extern Light myLight;
extern bool isShading;
extern int nfish;

void menu() {
	fishMove(1) ;

	GLint VCTrans_Menu = glutCreateMenu(VCTransMenu);
	glutAddMenuEntry(" Rotate x ", 1);
	glutAddMenuEntry(" Rotate y ", 2);
	glutAddMenuEntry(" Rotate z", 3);

	GLint Fish_Add = glutCreateMenu(FishMenu);
	glutAddMenuEntry(" 1 ", 1);
	glutAddMenuEntry(" 2 ", 2);
	glutAddMenuEntry(" 3", 3);
	glutAddMenuEntry(" 4 ", 4);
	glutAddMenuEntry(" 5 ", 5);
	glutAddMenuEntry(" 6", 6);
	glutAddMenuEntry(" 7 ", 7);
	glutAddMenuEntry(" 8 ", 8);
	glutAddMenuEntry(" 9 ", 9);
	glutAddMenuEntry(" 10 ", 10);
	glutAddMenuEntry(" 0 ", 0);


	glutCreateMenu(mainMenu);      // Create main pop-up menu.
	glutAddMenuEntry(" Reset ", 1);
	glutAddSubMenu(" View Transformations ", VCTrans_Menu);
	glutAddSubMenu(" Number of Fish ", Fish_Add);
	glutAddMenuEntry(" Quit", 2);
}

void mainMenu(GLint option) {
	switch (option){
		case 1:
			myCamera.setDefaultCamera();
			myWorld.resetWorld();
			myLight.reset();
			glUseProgram(0);  // disable GLSL shader
			nfish = 4;
			glutIdleFunc(NULL);
			glDisable(GL_LIGHTING);
			glDisable(GL_LIGHT0);
			isShading = false;
			break;
		case 2:
			exit(0);
			break;
	}
	glutPostRedisplay();
}

void VCTransMenu(GLint transOption) {
	coordinate = 3;
	type = transOption;
	glutPostRedisplay();
}

void FishMenu(GLint transOption) {
	FishAdd(transOption);
	glutPostRedisplay();
}

void viewTransforms(GLint x){
	GLfloat theta = (xBegin - x > 0) ? 1 : -1;
	if (type == 1) { //view rotate x
		myCamera.rotate(1.0, 0.0, 0.0, theta*0.5);
	}
	else if (type == 2) { //view rotate y
		myCamera.rotate(0.0, 1.0, 0.0, theta*0.5);
	}
	else if(type == 3) { //view rotate z
		myCamera.rotate(0.0, 0.0, 1.0, theta*0.5);
	}
	else if (type == 4) { //view translate x
		myCamera.translate(theta, 0.0, 0.0);
	}
	else if(type == 5) { //view translate y
		myCamera.translate(0.0, theta, 0.0);
	}
	else if(type == 6){ //view translate z
		myCamera.translate(0.0, 0.0, theta);
	}
}

void FishAdd(GLint x){
	if (x == 1){
		nfish = 1;
	}
	else if (x == 2){
		nfish = 2;
	}
	else if (x == 3){
		nfish = 3;
	}
	else if (x == 4){
		nfish = 4;
	}
	else if (x == 5){
		nfish = 5;
	}
	else if (x == 6){
		nfish = 6;
	}
	else if (x ==7){
		nfish = 7;
	}
	else if (x == 8){
		nfish = 8;
	}
	else if (x == 9){
		nfish = 9;
	}
	else if (x == 10){
		nfish = 10;
	}
	else if (x == 0){
		nfish = 0;
	}
}

void fishMove(int cont) {
	myWorld.fishdance() ;
	glutTimerFunc(40, fishMove,1);
	glutPostRedisplay();
}
