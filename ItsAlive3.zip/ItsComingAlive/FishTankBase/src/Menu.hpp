#ifndef MENU_HPP_
#define MENU_HPP_



#include <GL/glew.h>
#include <GL/glut.h>
#include "GL/glaux.h"


#include "World.hpp"
#include "Camera.hpp"
#include "solar/Solar.hpp"
#include "pebble.hpp"
#include "fish.hpp"
void menu();

void mainMenu(GLint option);
void VCTransMenu(GLint transOption);
void FishMenu(GLint transOption);
void ObjSubMenu(GLint objectOption);

void fishMove(int i) ;
void FishAdd(GLint i);


void move();
void viewTransforms(GLint);


#endif
