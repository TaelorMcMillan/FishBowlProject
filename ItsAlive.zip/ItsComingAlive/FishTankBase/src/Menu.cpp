#include "Menu.hpp"

extern GLint coordinate, selected;
extern GLint type, xBegin, a4option;
extern World myWorld;
extern Camera myCamera;
extern Light myLight;
extern bool isShading, isTexture;


//extern GLuint ProgramObject;

//extern GLint solarAnimation;
extern fish *myfish ;


void fishMove(int i) ;

// light properties
GLfloat ambient[] = { 0.1f, 0.1f, 0.3f, 1.0f };
GLfloat diffuse[] = { .6f, .6f, 1.0f, 1.0f };
GLfloat specular[] = { 1.0, 1.0, 1.0, 1.0 };
GLfloat positionSolar[] = { 0.0, 0.0, 0.0, 1.0 };
GLfloat position[] = { 1.8, 1.8, 1.5, 1.0 };
GLfloat lmodel_ambient[] = { 0.5, 0.5, 0.5, 1.0 };
GLfloat local_view[] = { 0.0 };

//Material
GLfloat no_mat[] = { 0.0, 0.0, 0.0, 1.0 };
GLfloat mat_ambient[] = { 0.7, 0.7, 0.7, 1.0 };
GLfloat mat_ambient_color[] = { 1, 1, 1, 1 };
GLfloat mat_diffuse[] = { 0.1, 0.5, 0.8, 1.0 };
GLfloat mat_specular[] = { 1.0, 1.0, 1.0, 1.0 };
GLfloat high_shininess[] = { 100.0 };
GLfloat mat_emission[] = { 1, 1, 1, 1 };

void menu() {
	fishMove(1) ;

	GLint VCTrans_Menu = glutCreateMenu(VCTransMenu);
	glutAddMenuEntry(" Rotate x ", 1);
	glutAddMenuEntry(" Rotate y ", 2);
	glutAddMenuEntry(" Rotate z", 3);

	glutCreateMenu(mainMenu);      // Create main pop-up menu.
	glutAddMenuEntry(" Reset ", 1);
	glutAddSubMenu(" View Transformations ", VCTrans_Menu);
	glutAddMenuEntry(" Quit", 2);
}



void mainMenu(GLint option) {
	switch (option){
		case 1:
			myCamera.setDefaultCamera();
			myWorld.resetWorld();
			myLight.reset();

			glUseProgram(0);  // disable GLSL shader

			glutIdleFunc(NULL);
			glDisable(GL_LIGHTING);
			glDisable(GL_LIGHT0);
			isShading = false;

			break;
		case 2:
			exit(0);
			break;
	}
	glutPostRedisplay();
}

void VCTransMenu(GLint transOption) {
	coordinate = 3;
	type = transOption;
	glutPostRedisplay();
}


void viewTransforms(GLint x){
	GLfloat theta = (xBegin - x > 0) ? 1 : -1;
	if (type == 1) { //view rotate x
		myCamera.rotate(1.0, 0.0, 0.0, theta*0.5);
	}
	else if (type == 2) { //view rotate y
		myCamera.rotate(0.0, 1.0, 0.0, theta*0.5);
	}
	else if(type == 3) { //view rotate z
		myCamera.rotate(0.0, 0.0, 1.0, theta*0.5);
	}
	else if (type == 4) { //view translate x
		myCamera.translate(theta, 0.0, 0.0);
	}
	else if(type == 5) { //view translate y
		myCamera.translate(0.0, theta, 0.0);
	}
	else if(type == 6){ //view translate z
		myCamera.translate(0.0, 0.0, theta);
	}

}



void fishMove(int cont) {
	myWorld.fishdance() ;
	glutTimerFunc(40, fishMove,1);
	glutPostRedisplay();



}
