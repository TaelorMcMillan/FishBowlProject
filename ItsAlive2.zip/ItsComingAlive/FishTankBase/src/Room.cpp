#include "Room.hpp"
extern Camera myCamera;
extern Light myLight;
extern bool isShading;
extern GLuint texture[];
extern bool isTexture;

Room::Room(){
	textureID = 5 ;
	ytop = 10 ; // y top
	ybot = -10 ; //y bottom
	zclose = 10 ; // z close
	zfar = -10 ; //zfar
	xleft = -10 ; //xleft
	xright = 10 ; //xright
    vertex[0][0] = xleft; vertex[0][1] = ybot; vertex[0][2] = zfar;
    vertex[1][0] = xleft; vertex[1][1] = ytop; vertex[1][2] = zfar;
    vertex[2][0] = xright; vertex[2][1] = ytop; vertex[2][2] = zfar;
    vertex[3][0] = xright; vertex[3][1] = ybot; vertex[3][2] = zfar;
    vertex[4][0] = xleft; vertex[4][1] = ybot; vertex[4][2] = zclose;
    vertex[5][0] = xleft; vertex[5][1] = ytop; vertex[5][2] = zclose;
    vertex[6][0] = xright; vertex[6][1] = ytop; vertex[6][2] = zclose;
    vertex[7][0] = xright; vertex[7][1] = ybot; vertex[7][2] = zclose;

    face[0][0] = 0; face[0][1] = 1; face[0][2] = 2; face[0][3] = 3;
    face[1][0] = 7; face[1][1] = 6; face[1][2] = 5; face[1][3] = 4;
    face[2][0] = 0; face[2][1] = 4; face[2][2] = 5; face[2][3] = 1;
    face[3][0] = 2; face[3][1] = 1; face[3][2] = 5; face[3][3] = 6;
    face[4][0] = 3; face[4][1] = 2; face[4][2] = 6; face[4][3] = 7;
    face[5][0] = 0; face[5][1] = 3; face[5][2] = 7; face[5][3] = 4;

	faceColor[0][0] = 1.0, faceColor[0][1] = 0.0; faceColor[0][2] = 0.0;
	faceColor[1][0] = 0.0, faceColor[1][1] = 1.0; faceColor[1][2] = 0.0;
	faceColor[2][0] = 0.0, faceColor[2][1] = 0.0; faceColor[2][2] = 1.0;
	faceColor[3][0] = 1.0, faceColor[3][1] = 1.0; faceColor[3][2] = 0.0;
	faceColor[4][0] = 1.0, faceColor[4][1] = 0.0; faceColor[4][2] = 1.0;
	faceColor[5][0] = 0.0, faceColor[5][1] = 1.0; faceColor[5][2] = 1.0;

	faceNormal[0][0] = 0.0,faceNormal[0][1] = 0.0,faceNormal[0][2] = -1.0,
	faceNormal[1][0] = 0.0, faceNormal[1][1] = 0.0, faceNormal[1][2] = 1.0;
	faceNormal[2][0] = -1.0, faceNormal[2][1] = 0.0, faceNormal[2][2] = 0.0;
	faceNormal[3][0] = 0.0, faceNormal[3][1] = 1.0, faceNormal[3][2] = 0.0;
	faceNormal[4][0] = 1.0, faceNormal[4][1] = 0.0, faceNormal[4][2] = 0.0;
	faceNormal[5][0] = 0.0, faceNormal[5][1] = -1.0, faceNormal[5][2] = 0.0;


}


void Room::drawFace()
{

		glEnable(GL_TEXTURE_2D);
		glBindTexture(GL_TEXTURE_2D,texture[13]);
		glBegin(GL_QUADS);
		/* Floor */
		glTexCoord2f(0.0, 0.0);
		glVertex3f(-10,-7,-10);
		glTexCoord2f(1.0, 0.0);
		glVertex3f(10,-7,-10);
		glTexCoord2f(1.0, 1.0);
		glVertex3f(10,-7,10);
		glTexCoord2f(0.0, 1.0);
		glVertex3f(-10,-7,10);
		/* Ceiling */
		glTexCoord2f(0.0, 0.0);
		glVertex3f(-10,10,-10);
		glTexCoord2f(1.0, 0.0);
		glVertex3f(10,10,-10);
		glTexCoord2f(1.0, 1.0);
		glVertex3f(10,10,10);
		glTexCoord2f(0.0, 1.0);
		glVertex3f(-10,10,10);
		glEnd();
		/* Walls */
		glBindTexture(GL_TEXTURE_2D,texture[12]);
		glBegin(GL_QUADS);
		glTexCoord2f(0.0, 0.0);
		glVertex3f(-10,-10,10);
		glTexCoord2f(1.0, 0.0);
		glVertex3f(10,-10,10);
		glTexCoord2f(1.0, 1.0);
		glVertex3f(10,10,10);
		glTexCoord2f(0.0, 1.0);
		glVertex3f(-10,10,10);

		glTexCoord2f(0.0, 0.0);
		glVertex3f(-10,-10,-10);
		glTexCoord2f(1.0, 0.0);
		glVertex3f(10,-10,-10);
		glTexCoord2f(1.0, 1.0);
		glVertex3f(10,10,-10);
		glTexCoord2f(0.0, 1.0);
		glVertex3f(-10,10,-10);

		glTexCoord2f(0.0, 0.0);
		glVertex3f(10,10,10);
		glTexCoord2f(1.0, 0.0);
		glVertex3f(10,-10,10);
		glTexCoord2f(1.0, 1.0);
		glVertex3f(10,-10,-10);
		glTexCoord2f(0.0, 1.0);
		glVertex3f(10,10,-10);

		glTexCoord2f(0.0, 0.0);
		glVertex3f(-10,10,10);
		glTexCoord2f(1.0, 0.0);
		glVertex3f(-10,-10,10);
		glTexCoord2f(1.0, 1.0);
		glVertex3f(-10,-10,-10);
		glTexCoord2f(0.0, 1.0);
		glVertex3f(-10,10,-10);
		glEnd();
		glDisable(GL_TEXTURE_2D);

}

void Room::draw()
{
    		drawFace();
}
bool Room::isFrontface(int faceindex, Camera camera) {
	GLfloat v[4];
	v[0] = faceNormal[faceindex][0];
	v[1] = faceNormal[faceindex][1];
	v[2] = faceNormal[faceindex][2];
	v[3] = 0.0;

	mc.multiplyVector(v);

	if (pmc != NULL) {
		pmc->multiplyVector(v);
		return  (pmc->mat[0][3]-camera.eye.x) * v[0] + (pmc->mat[1][3]-camera.eye.y) * v[1] +  (pmc->mat[2][3]-camera.eye.z) * v[2] < 0;
	} else

	return  (mc.mat[0][3]-camera.eye.x) * v[0] + (mc.mat[1][3]-camera.eye.y) * v[1] +  (mc.mat[2][3]-camera.eye.z) * v[2] < 0;
}






